<?php include("weather.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <?php require("includes/title.html"); ?>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="js/jquery.pngFix.js"></script>
    </head>
    <body id="inner">
		<div id="shell">
			<div id="header">
            	<h1 id="logo"><a href="home_pl.php" class="no-text" title="Touring.bg">TOURING</a></h1>
                <div id="head-right">
                	<?php require("includes/langs_bg.html"); ?>
                    <div class="cl no-text"><!-- --></div>
                    <?php require("includes/menu-top/pl_destinations.html"); ?>
                </div>
                <div class="cl no-text"><!-- --></div>
            </div>
            <div id="content">
            	<div id="left">
                	<?php require("includes/readmore_wiki_pl.html"); ?>
                    <div id="buylink" class="box"><h1 style="background: url('css/images/left-weather-head.png') repeat scroll 0 0 transparent;">E-Tickets:</h1><a style="width: 200px; margin: 5px auto; display: block;" href="https://eshop.amsbus.cz/tourbg/koupitjizdenku/" target="_blank"><img style="width: 100%;" alt="images/gosloto-video-process-click.gif" src="images/gosloto-video-process-click.gif"></a></div><div id="weather" class="box">
                    	<h1>Wiadomość:</h1>
                        <p style="padding:10px 20px 0;"><strong>Szanowni Państwo, możecie zarezerwować i kupić bilet przez E Pay i Easy Pay. </strong></p>
                        <p style="padding:10px 20px 0;"><strong> Więcej informacji mogą Państwo uzyskać kontaktując sie z nami telefonicznie.</strong></p>
                    </div>
                    <div id="left-contacts">
                    	<p>Adres: <b>WARSZAWA 00-728</b></p>
                        <p><b>ul. "Bobrowiecka" 4, lok.4</b></p>
                        <p>Mobile: <b>0048 607 185 278</b></p>
                        <p>E-mail: <a href="mailto:touring.pl@touring.bg">touring.pl@touring.bg</a><br />
                        </p>
                    </div>
                </div>
                <div id="right">
                	<div id="crumb">
                    	<h1>CENNIK</h1>
                    </div>
					<table class="destinations dest-prices" border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td colspan="3" width="460" class="bold bg-nb border-right">Przewoźnik:</td>
                                <td width="150" class="bold bg-nb">Wyjazd z miast:</td>
                            </tr>
                            <tr>
                            	<td colspan="3" width="460" class="title bg lblue border-right">TOURING BUS</td>
                                <td width="150" class="subtitle bg orange">WARSZAWA, ŁÓDŹ</td>
                            </tr>
                            <tr>
                            	<td width="210" class="bold bg">Przyjazd do:</td>
                                <td width="100" class="small bg">strona</td>
                                <td width="150" class="small bg border-right">zniżka</td>
                                <td width="150" class="price bg"  >BRUTTO</td>
                            </tr>
                            <tr>
                            	<td rowspan="8" class="title bg orange border-right">SOFIA</td>
                                <td rowspan="4" class="asar bg border-right">AS</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />14->26l. i pow. 60l.<br />7->14l.<br />DZIECIĘCA</td>
                                <td class="price bg-aqua">380,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">342,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">304,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">190,00 zł</td>
                            </tr>
                            <tr>
                            	<td rowspan="4" class="asar bg border-right">AR</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />
                                  14-&gt;26l. i pow. 60l.<br />
                                  7-&gt;14l.<br />
                                DZIECIĘCA</td>
                                <td class="price bg-aqua">600,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">540,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">480,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">300,00 zł</td>
                            </tr>
                        </tbody>
                    </table>
					
					 <table class="destinations dest-prices" border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td colspan="3" width="460" class="bold bg-nb border-right">Przewoźnik:</td>
                                <td width="150" class="bold bg-nb">Wyjazd z miast:</td>
                            </tr>
                            <tr>
                            	<td colspan="3" width="460" class="title bg lblue border-right">TOURING BUS</td>
                                <td width="150" class="subtitle bg orange">CZĘSTOCHOWA, KATOWICE</td>
                            </tr>
                            <tr>
                            	<td width="210" class="bold bg">Przyjazd do:</td>
                                <td width="100" class="small bg">strona</td>
                                <td width="150" class="small bg border-right">zniżka</td>
                                <td width="150" class="price bg">BRUTTO</td>
                            </tr>
                            <tr>
                            	<td rowspan="8" class="title bg orange border-right">SOFIA</td>
                                <td rowspan="4" class="asar bg border-right">AS</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />14->26l. i pow. 60l.<br />7->14l.<br />DZIECIĘCA</td>
                                <td class="price bg-aqua">360,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">324,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">288,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">180,00 zł</td>
                            </tr>
                            <tr>
                            	<td rowspan="4" class="asar bg border-right">AR</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />14->26l. i pow. 60l.<br />7->14l.<br />DZIECIĘCA</td>
                                <td class="price bg-aqua">560,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">504,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">448,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">280,00 zł</td>
                            </tr>
                        </tbody>
                    </table>
					
                    <table class="destinations dest-prices" border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <td colspan="3" width="460" class="bold bg-nb border-right">Przewoźnik:</td>
                                <td width="150" class="bold bg-nb">Wyjazd z miast:</td>
                            </tr>
                            <tr>
                            	<td colspan="3" width="460" class="title bg lblue border-right">TOURING BUS</td>
                                <td width="150" class="subtitle bg orange">KRAKÓW</td>
                            </tr>
                            <tr>
                            	<td width="210" class="bold bg">Przyjazd do:</td>
                                <td width="100" class="small bg">strona</td>
                                <td width="150" class="small bg border-right">zniżka</td>
                                <td width="150" class="price bg">BRUTTO</td>
                            </tr>
                            <tr>
                            	<td rowspan="8" class="title bg orange border-right">SOFIA</td>
                                <td rowspan="4" class="asar bg border-right">AS</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />14->26l. i pow. 60l.<br />7->14l.<br />DZIECIĘCA</td>
                                <td class="price bg-aqua">340,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">306,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">272,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">170,00 zł</td>
                            </tr>
                            <tr>
                            	<td rowspan="4" class="asar bg border-right">AR</td>
                                <td rowspan="4" class="people bg border-right">NORMALNY<br />14->26l. i pow. 60l.<br />7->14l.<br />DZIECIĘCA</td>
                                <td class="price bg-aqua">550,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">495,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">440,00 zł</td>
                            </tr>
                            <tr>
                            	<td class="price bg">275,00 zł</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <div id="prices-legend">
                    	<div class="row">
                            <div class="cell1"><b>RODZAJE TARYF</b></div>
                            <div class="cell2">AS &ndash; w jedną stronę</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                    	<div class="row">
                            <div class="cell1">&nbsp;</div>
                            <div class="cell2">AR &ndash; w dwie strony</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                    	<div class="row">
                            <div class="cell1"><b>NORMALNY</b></div>
                            <div class="cell2">od 27 do 60 lat</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                    	<div class="row">
                            <div class="cell1"><b>14->26l. i pow. 60l.</b></div>
                            <div class="cell2">od 14 lat do ukończenia 26 lat i powyżej 60 lat, emeryci, renciści</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                    	<div class="row">
                            <div class="cell1"><b>7->14l.</b></div>
                            <div class="cell2">od 7 do 14 lat</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                    	<div class="row">
                            <div class="cell1"><b>DZIECIĘCA</b></div>
                            <div class="cell2">dzieci od 3 lat do ukończenia 7 lat</div>
                            <div class="cl no-text"><!-- --></div>
                        </div>
                        <div class="row">
                        	<i class="small">Dzieci do ukończenia 3 lata &ndash; za darmo bez prawa na miejsce</i>
                        </div>
                    </div>
                </div>
                <div class="cl no-text"><!-- --></div>
            </div>
            <?php include("includes/footer_pl.html"); ?>
        </div>
    </body>
</html>